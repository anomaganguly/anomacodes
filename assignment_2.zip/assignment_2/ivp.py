import numpy as np
import math
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

n=20
def f1(t,w):
	dydt=t*math.exp(t)-2*w
	return (dydt)
def f2(t,w):
	dydt=1-math.pow(t-w,2)
	return (dydt)
def f3(t,w):
	dydt=1+w/t
	return (dydt)
def f4(t,w):
	dydt=math.cos(2*t)+math.sin(3*t)
	return (dydt)



sol1 = solve_ivp(f1, [0, 1], [0],t_eval=[i for i in np.linspace(0,1,n)])	
sol2 = solve_ivp(f2, [2, 3], [0],t_eval=[i for i in np.linspace(2,3,n)])	
sol3 = solve_ivp(f3, [1, 2], [2],t_eval=[i for i in np.linspace(1,2,n)])	
sol4 = solve_ivp(f4, [0, 1], [1],t_eval=[i for i in np.linspace(0,1,n)])	

t1=np.asarray(sol1.t)
y1=np.asarray(sol1.y)



t2=np.asarray(sol2.t)
y2=np.asarray(sol2.y)

print(y2, t2)

t3=np.asarray(sol3.t)
y3=np.asarray(sol3.y)

t4=np.asarray(sol4.t)
y4=np.asarray(sol4.y)


plt.plot(t1,y1)
plt.plot(t2,y2)
plt.plot(t3,y3)
plt.plot(t4,y4)
plt.xlabel('x')    #plotting
plt.ylabel('y(x)')
plt.show()
