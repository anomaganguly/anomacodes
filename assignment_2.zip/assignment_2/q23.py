#3. Solving an ode using RK-4 method

import numpy as np
import math

def f(x, w0, w1): 
	y = w0
	z = w1
	dzdx = 2*z - y + x*(math.exp(x) - 1)
	dydx = z
	return [dydx, dzdx]

h = 0.1 							#Step size
n = np.int(1/h) + 1

wr = np.zeros(shape = (n+1, 2)) 	#Declaring and initialising the arrays
k1 = np.zeros(shape = (n+1, 2))
k2 = np.zeros(shape = (n+1, 2))
k3 = np.zeros(shape = (n+1, 2))
k4 = np.zeros(shape = (n+1, 2))
x = np.zeros(n+1)
y = np.zeros(n+1)


for i in range (0, n):		#RK4
	for j in range (0, 1):
		x[i+1] = x[i] + h
		k1 = f(x[i], wr[i][j], wr[i][j+1])
		k2 = f(x[i]+h/2., wr[i][j] + h*k1[0]/2., wr[i][j+1]+ h*k1[1]/2.)
		k3 = f(x[i]+h/2., wr[i][j] + h*k2[0]/2., wr[i][j+1] + h*k2[1]/2.)
		k4 = f(x[i]+h, wr[i][j] + h*k3[0], wr[i][j+1] + h*k3[1])
		wr[i+1][j] = wr[i][j] + 1/6*h*(k1[0] + 2*(k2[0] + k3[0]) + k4[0])
		wr[i+1][j+1] = wr[i][j+1] + 1/6*h*(k1[1] + 2*(k2[1] + k3[1]) + k4[1])

print("The solution for y is :")

for i in range (0, n+1):
	y[i] = wr[i][0]
	print(y[i], "at", x[i])	  #final solution y