#6. Using relaxation method to solve bvp

import numpy as np
from numpy.linalg import solve
import matplotlib.pyplot as plt

def f(x, h, y0, y1):	#defining the rhs for ode
	fn = -9.8
	return fn

g = 9.8
h = 0.1					#step-size
n = int(10/h)

a1 = 0					#boundary conditions
a2 = 0					#solving the matrix equation AX + B = C

a = np.zeros(shape = (n-1, n-1))#declaring A matrix
b = np.zeros(shape = (n-1, 1))	#B vector
b[0] = a1						#boundary conditions
b[n-2] = a2
c = np.dot(np.ones(shape = (n-1, 1)), -g*h*h) - b	#C vector

for i in range (0, n-1):	#setting A matrix
	a[i][i] = -2
	if (i-1 == -1): 
		a[i][i+1] = 1
	elif (i == n-2):
		a[i][i-1] = 1
	else: 
		a[i][i+1] = 1
		a[i][i-1] = 1

x = solve(a, c)				#solving for X

t_plot = np.zeros(n+1)
t_plot[n] = 10.
y_plot = np.zeros(n+1)
y_plot[0] = a1
y_plot[n] = a2

y_a = np.zeros(n+1)			
y_a[0] = a1
y_a[n] = a2

for i in range (0, n-1):
	y_plot[i+1] = x[i]			#numerical soln
	t_plot[i+1] = t_plot[i] + h
	y_a[i+1] = 0.1*(10*a1 +(a2 - a1 + 50*g -5*g*t_plot[i+1])*t_plot[i+1])#analytic soln

plt.plot(t_plot, y_plot, 'r+', label = 'Numerical solution')
plt.plot(t_plot, y_a, 'g+', label = 'Analytic soln')

plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()

plt.savefig('im26.png')