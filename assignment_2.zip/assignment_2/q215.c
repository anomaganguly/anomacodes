//Solving ivp using C program

#include <stdio.h>
#include<math.h>
#include<stdlib.h>

double f1(float t, float y)		
{
    return(y - t*t + 1);
}

double f2(float t)		//analytic solution
{
    return(pow((t+1),2)- 0.5*exp(t));
}

int main()
{

	FILE *mptr;
    	mptr=fopen("errorivp.dat", "w");	//opening file to save error


	float ti, tf, h;						//declaring the vaiables
	int i, n;
	double y[n], ya[n] ,t[n], er[n], erb[n];
	
	h = 0.2;	
	ti = 0;									//range of t
	tf = 2;									//step-size
	n = (tf-ti)/h + 1;
	
	t[0] = 0;								//initializing the values
	y[0] = 0.5;
	ya[0] = 0.5;
	er[0] = 0.0;
	erb[0]= 0.0;
	
	printf("t");
	printf("\t\terror");
	printf("\t\terror bound\n");
	
	printf("%lf\t", t[0]);
	printf("%lf\t", er[0]);
	printf("%lf\n",erb[0]);
	
	fprintf(mptr,"%e\t%e\t%e\n", t[0], y[0], ya[0]);

	for(i=0; i<(n-1); i++)
	{
		y[i+1] = y[i] + h*f1(t[i],y[i]);		//Euler method
		t[i+1] = t[i] + h;
		ya[i+1] = f2(t[i+1]);
		er[i+1] = fabs(y[i+1] - ya[i+1]);		//error at each step
		erb[i+1] = 0.05*(exp(2)-4)*(exp(t[i+1])-1);	//error bound							
		printf("%lf\t", t[i+1]);
		printf("%lf\t", er[i+1]);
		printf("%lf\n",erb[i+1]);
		fprintf(mptr,"%e\t%e\t%e\n",t[i+1], y[i+1], ya[i+1]);//printing into the file
	}
	
   	return(0);
}
