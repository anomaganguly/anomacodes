#Solving coupled ivp

import numpy as np
import math
import matplotlib.pyplot as plt

def f(u1, u2, u3, t):
	f1 = u1 + 2*u2 - 2*u3 + np.exp(-t)
	f2 = u2 + u3 -2*np.exp(-t)
	f3 = u1 + 2*u2 + np.exp(-t)
	return (np.asarray([f1, f2, f3]))

h = 0.05		#step-size
n = np.int(1/h)	

u1 = np.empty(n+1)
u2 = np.empty(n+1)
u3 = np.empty(n+1)
t = np.empty(n+1)

u1[0] = 3.	#setting the initial conditions
u2[0] = -1.
u3[0] = 1.


for i in range (0, n):		#RK4
	t[i+1] = t[i] + h
	k1 = h*f(u1[i], u2[i], u3[i], t[i])[0]
	l1 = h*f(u1[i], u2[i], u3[i], t[i])[1]
	m1 = h*f(u1[i], u2[i], u3[i], t[i])[2]
	
	k2 = h*f(u1[i] + k1/2., u2[i] + l1/2., u3[i] + m1/2., t[i] + h/2.)[0]
	l2 = h*f(u1[i] + k1/2., u2[i] + l1/2., u3[i] + m1/2., t[i] + h/2.)[1]
	m2 = h*f(u1[i] + k1/2., u2[i] + l1/2., u3[i] + m1/2., t[i] + h/2.)[2]
	
	k3 = h*f(u1[i] + k2/2., u2[i] + l2/2., u3[i] + m2/2., t[i] + h/2.)[0]
	l3 = h*f(u1[i] + k2/2., u2[i] + l2/2., u3[i] + m2/2., t[i] + h/2.)[1]
	m3 = h*f(u1[i] + k2/2., u2[i] + l2/2., u3[i] + m2/2., t[i] + h/2.)[2]
	
	k4 = h*f(u1[i] + k3, u2[i] + l3, u3[i] + m3, t[i] + h)[0]
	l4 = h*f(u1[i] + k3, u2[i] + l3, u3[i] + m3, t[i] + h)[1]
	m4 = h*f(u1[i] + k3, u2[i] + l3, u3[i] + m3, t[i] + h)[2]
	
	u1[i+1] = u1[i] + 1/6*(k1 + 2*(k2 + k3) + k4)
	
	u2[i+1] = u2[i] + 1/6*(l1 + 2*(l2 + l3) + l4)
	
	u3[i+1] = u3[i] + 1/6*(m1 + 2*(m2 + m3) + m4)
	
plt.plot(t, u1, 'r+', label='u1')	#plotting
plt.plot(t, u2, 'b*', label='u2')
plt.plot(t, u3, 'g.', label='u3')

plt.xlabel('t')
plt.ylabel('u1(t), u2(t), u3(t)')
plt.legend()
plt.show()