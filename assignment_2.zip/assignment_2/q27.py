# Solving initial value problems

import numpy as np
import math
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def f1(t, y):					#defining rhs of all the ode's
	fn = t*math.exp(3*t) - 2*y
	return fn

def f2(t, y):
	fn = 1 - math.pow(t-y, 2)
	return fn
	
def f3(t, y):	
	fn = 1 + y/t
	return fn

def f4(t, y):	
	fn = math.cos(2*t) + math.sin(3*t)
	return fn

h = 0.01
n = np.int(1/h)

y1 = np.zeros(n+1)		#declaring arrays for numerical and analytic soln
y1a = np.zeros(n+1)
y2 = np.zeros(n+1)
y2a = np.zeros(n+1)
y3 = np.zeros(n+1)
y3a = np.zeros(n+1)
y4 = np.zeros(n+1)
y4a = np.zeros(n+1)

t1 = np.zeros(n+1)
t2 = np.zeros(n+1)
t3 = np.zeros(n+1)

y2[0] = 2.			#setting the initial condn for all different ode's
y2a[0] = 2.
y3[0] = 2.
y3a[0] = 2.
y4[0] = 1.
y4a[0] = 1.

t1[n] = 1.

t2[0] = 2.	#putting this to 1 as given in assignment blows up the soln!!
t2[n] = 3.

t3[0] = 1.
t3[n] = 2.


for i in range (0, n):			#solving for ode's using solve_ivp
	t1[i+1] = t1[i] + h
	s1 = solve_ivp(f1, [t1[0], t1[100]], [y1[0]], t_eval = [t1[i+1]])
	y1[i+1] = np.asscalar(s1.y)
	y1a[i+1] = (1/25)*np.exp(-2*t1[i+1])*(1 - np.exp(5*t1[i+1]) + 5*np.exp(5*t1[i+1])*t1[i+1])
	
	t2[i+1] = t2[i] + h
	s2 = solve_ivp(f2, [t2[0], t2[100]], [y2[0]], t_eval = [t2[i+1]])
	y2[i+1] = np.asscalar(s2.y)
	y2a[i+1] = t2[i+1]
	
	t3[i+1] = t3[i] + h
	s3 = solve_ivp(f3, [t3[0], t3[100]], [y3[0]], t_eval = [t3[i+1]])
	y3[i+1] = np.asscalar(s3.y)
	y3a[i+1] = (2 + np.log(t3[i+1]))*t3[i+1]
	
	s4 = solve_ivp(f4, [t1[0], t1[100]], [y4[0]], t_eval = [t1[i+1]])
	y4[i+1] = np.asscalar(s4.y)
	y4a[i+1] = (1/6)*(8 - 2*np.cos(3*t1[i+1]) + 3*np.sin(2*t1[i+1]))
	

figure, axes = plt.subplots(nrows = 2, ncols = 2)	#plotiing

axes[0, 0].plot(t1, y1,' b')
axes[0, 0].plot(t1, y1a, 'r')
axes[0, 0].set_title('1')
axes[0, 0].set_xlabel('t')
axes[0, 0].set_ylabel('y(t)')

axes[0, 1].plot(t2, y2, 'b')
axes[0, 1].plot(t2, y2a, 'r')
axes[0, 1].set_title('2')
axes[0, 1].set_xlabel('t')
axes[0, 1].set_ylabel('y(t)')

axes[1, 0].plot(t3, y3, 'b')
axes[1, 0].plot(t3, y3a, 'r')
axes[1, 0].set_title('3')
axes[1, 0].set_xlabel('t')
axes[1, 0].set_ylabel('y(t)')

axes[1, 1].plot(t1, y4, 'b')
axes[1, 1].plot(t1, y4a, 'r')
axes[1, 1].set_title('4')
axes[1, 1].set_xlabel('t')
axes[1, 1].set_ylabel('y(t)')


figure.tight_layout()

plt.savefig()