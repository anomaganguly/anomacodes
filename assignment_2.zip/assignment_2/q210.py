# Solving an ivp with one boundary going to inf by doing a change to variables from t to u = t/(t+1)
import numpy as np

def f(u, x):	#defing rhs of ode in terms of u
	return (np.power((1 - u), -2)*(1/(np.power(x, 2) + np.power(u/(1-u), 2))))



h = 0.01			#step-size
n = np.int(1/h) + 1

u = np.zeros(n)  	#declaring u and x array
x = np.zeros(n)

x[0] = 1.			#initializing x

t = 3.5*np.power(10, 6)	#t at which we want x
u_t = t/(t + 1)

for i in range (0, n-1):		#RK4
	u[i+1] = u[i] + h
	k1 = h*f(u[i], x[i])
	k2 = h*f(u[i] + h/2., x[i] + k1/2.)
	k3 = h*f(u[i] + h/2., x[i] + k2/2.)
	k4 = h*f(u[i] + h, x[i] + k3)
	x[i+1] = x[i] + (1/6)*(k1 + 2*(k2 + k3) + k4)
	if(abs(u[i] - u_t) < h):
		print("x at t = ", t, "is", x[i])	#finding the required x

print("u points", t, "\n solution x",x)