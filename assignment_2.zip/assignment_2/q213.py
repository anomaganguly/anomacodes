#13. Euler method to solve an ivp

import numpy as np
import math
import matplotlib.pyplot as plt

from scipy.integrate import solve_ivp

def f(t, w0, w1): 
	y = w0
	z = w1
	dzdt = 2.*z/t - 2*(y/(t*t)) + t*math.log(t)
	dydt = z
	return (np.asarray([dydt, dzdt]))
	
def a(t):			#analytic soln
	y = (7./4.)*t + (t*t*t/2.)*math.log(t) - (3./4.)*t*t*t
	return y

h = 0.001 							#Step size
n = np.int(1/h)

wr = np.zeros(shape = (n+1, 2)) 	#Declaring and initialising the arrays
x = np.zeros(n+1)
y = np.zeros(n+1)
ya = np.zeros(n+1)

x[0] = 1.							#Setting the initial conditions	
wr[0][0] = 1.
wr[0][1] = 0.
ya[0] = 1. 


for i in range (0, n):		
	x[i+1] = x[i] + h
	wr[i+1][0] = wr[i][0] + h*f(x[i], wr[i][0], wr[i][1])[0] 	#Euler method
	wr[i+1][1] = wr[i][1] + h*f(x[i], wr[i][0], wr[i][1])[1]
	ya[i+1] = a(x[i+1])


for i in range (0, n+1):
	y[i] = wr[i][0]
	
plt.plot(x, y, 'r', label='Euler sol')
plt.plot(x, ya, 'b', label='Analytic sol')
plt.xlabel('x')
plt.ylabel('y(x)')
plt.legend()
plt.show()	