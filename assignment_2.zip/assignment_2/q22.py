#2. Solving an ivp using Euler's method
import numpy as np
import math
import matplotlib.pyplot as plt

def f(w, t): 		#defining rhs of ode
	fn = w/t - np.square(w/t)
	return fn

h = 0.1				#step-size
n = np.int(1/h)

wf = np.zeros(n+1)	#declaring the arrays
wa = np.zeros(n+1)
t = np.zeros(n+1)
err = np.zeros(n+1)
era = np.zeros(n+1)

wf[0] = 1.			#initialising the arrays
wa[0] = 1.
t[0] = 1.

print("Absolute error\t\tRelative error\t\tt")
for i in range (0, n):						#Euler method
	t[i+1] = t[i] + h
	wf[i+1] = wf[i] + h*f(wf[i], t[i])
	wa[i+1] = t[i+1]/(1 + math.log(t[i+1]))  #From the analytic solution
	err[i+1] = abs(wa[i+1] - wf[i])
	era[i+1] = err[i+1]/wa[i+1]
	print(err[i+1], era[i+1], t[i+1])
	
plt.plot(t, wf, 'r+', label='Euler sol')
plt.plot(t, wa, 'b*', label='Analytic sol')
plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.show()