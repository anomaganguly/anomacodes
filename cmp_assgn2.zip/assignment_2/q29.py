# Adaptive step size control

import numpy as np
import math
import matplotlib.pyplot as plt

t1 = 1				#initial t is 1
t2 = 1

h1 = 0.1			#defining the step-sizes
h2 = 2*h1

y1 = -2 			#initial conditions
y2 = -2 

d = 0.0001

t = []
x = []
x.append(y1)
t.append(t1)

def f(y,t):
	return((y*y+y)/t)

while(t1 <= 10.1):
	yr = y1
	tr = t1
	
	l1 = h1*(f(y1, t1))					#using rk4 at t+h1 
	l2 = h1*(f(y1 + l1/2, t1 + h1/2))
	l3 = h1*(f(y1 + l2/2, t1 + h1/2))
	l4 = h1*(f(y1 + l3, t1 + h1))
	y1 = y1 + (1/6)*(l1 + 2*l2 + 2*l3 + l4)
	yrr = y1
	t1 = t1 + h1
	
	l1 = h1*(f(y1, t1))					#using rk4 at t+2h1 
	l2 = h1*(f(y1 + l1/2, t1 + h1/2))
	l3 = h1*(f(y1 + l2/2, t1 + h1/2))
	l4 = h1*(f(y1 + l3, t1 + h1))
	y1 = y1 + (1/6)*(l1 + 2*l2 + 2*l3 + l4)
	t1 = t1 + h1
	
	k1 = h2*(f(y2, t2))					#using rk4 directly at t+h2
	k2 = h2*(f(y2 + k1/2, t2 + h2/2))
	k3 = h2*(f(y2 + k2/2, t2 + h2/2))
	k4 = h2*(f(y2 + k3, t2 + h2))
	y2 = y2 + (1/6)*(k1 + 2*k2 + 2*k3 + k4)
	t2 = t2 + h2

	if (h1*pow(d*30/(abs(y2-y1)),1/5) < h1):	#imposing the required accuracy
		h1 = h1*pow(d*30/(abs(y2-y1)), 1/5)
		h2 = 2*h1
		y1 = yr
		t1 = tr
		y2 = yr
		t2 = tr
	else:
		h1=h1*pow(d*30/(abs(y2-y1)), 1/5)
		x.append(y1)
		t.append(t1)
		



y = np.asarray(x)				#final solution
tm = np.asarray(t)

plt.plot(tm, y, 'r*')			#plotting
plt.xlabel('t')    
plt.ylabel('y(t)')
plt.show()