#5. Shooting method to solve bvp

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt


def f(t, w): 		#defining the rhs of second order ode into coupled first order ode
	g = 10
	x = w[1]
	v = w[0]
	dvdt = -g
	dxdt = v
	return [dvdt, dxdt]
	
def s(ti, tf, w0):	#solving ode using different initial conditions evaluated at boundary
	soln = solve_ivp(f, [ti, tf], w0, t_eval = [tf])	
	return [soln.y]

def sl(ti, tf, w0):
	sol = solve_ivp(f, [ti, tf], w0, t_eval = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])	
	return [sol.y]	
	
w0 = [-16., 0.]		#two guesses on v as initial condition (first element of array) 
w1 = [100., 0.]		#initial condition of x is 0 (second element of array)

wg = [0., 0.]		#stores the candidate v

solvg=[]

ti = 0.				#initial and final time
tf = 10.

sol = s(ti, tf, w0)

cnt = 0				#to calculate the number of steps to find the soln using bisection method


solv0 = s(ti, tf, w0)#solution due to two initial guesses on v
solv1 = s(ti, tf, w1)


if (np.sign(solv0[0][1]) != np.sign(solv1[0][1])): #bisection method

	while(abs(sol[0][1]) > 0.0001):
		delw = (w1[0] + w0[0])/2. #new candidate for y 
		wg[0] = delw 
		solg = s(ti, tf, wg)
		solvg.append(sl(ti, tf, wg)[0][1])	#storing the y values at all points
		
		if (np.sign(solg[0][1]) == np.sign(solv0[0][1])):
			w0[0] = wg[0]
			solv0 = s(ti, tf, w0)
			sol = solv0
		else:
			w1[0] = wg[0]  
			solv1 = s(ti, tf, w1)
			sol = solv1
			cnt = cnt + 1
else:
	print("Wrong choice of guesses!")
		
		
y = np.asarray(solvg) 	#converting list to array


t = np.zeros(11)

y1 = np.zeros(11)	# y for 6 candidates
y2 = np.zeros(11)
y3 = np.zeros(11)
y4 = np.zeros(11)
y5 = np.zeros(11)
y6 = np.zeros(11)

for j in range (0, 11):	#storing the values for y
	t[j] = j
	y1[j] = solvg[0][j] 
	y2[j] = solvg[1][j]
	y3[j] = solvg[2][j]
	y4[j] = solvg[3][j]
	y5[j] = solvg[5][j]
	y6[j] = solvg[20][j]
	
	
plt.plot(t, y1, label = 'candidate soln 1')
plt.plot(t, y2, label ='candidate soln 2')
plt.plot(t, y3, label ='candidate soln 3') 
plt.plot(t, y4, label ='candidate soln 4') 
plt.plot(t, y5, label ='candidate soln 5')
plt.plot(t, y6, label ='matching soln') 

plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.show()	