#1. The prog for backward integration with Euler’s Method

import numpy as np
import math 
import matplotlib.pyplot as plt
	
def sol(w, x, h):
	coeff = [20*h, -40*h*x + 1., 20*h*x*x - 2*x*h - w] #solving the polynomial equation on rhs of ode2
	s = np.roots(coeff)
	for i in range (0, 2):
		if (s[i] >= 0.):
			return s[i]

h = 0.1						#step-size
n = np.int(1/h)
w1 = np.empty(n+1)		 	#Declaring arrays
x = np.empty(n+1)

w1[0] = np.exp(1)   		#Initialization
x[0] = 0.

print("Backward Euler for first ode gives: ")
print("y = ", w1[0], " at x = ", x[0])

for i in range (0, n):		#Backward Euler_1
	x[i+1] = x[i] + h
	w1[i+1] = w1[i]/(1 - h*(-9.))
	print("y = ", w1[i+1], " at x = ", x[i+1])
	
print("Backward Euler for second ode gives: ")	
		
w2 = np.empty(n+1)			#Declaring arrays
w2[0] = 1./3.				#Initialization

print("y = ", w2[0], " at x = ", x[0])

for i in range (0, n):		#Backward Euler_2
	x[i+1] = x[i] + h
	w2[i+1] = sol(w2[i], x[i+1], h)
	print("y = ", w2[i+1], " at x = ", x[i+1])
	

plt.plot(x, w1, 'r+', label='First ode')
plt.plot(x, w2, 'b*', label='Second ode')
plt.xlabel('x')
plt.ylabel('y(x)')
plt.legend()
plt.show()