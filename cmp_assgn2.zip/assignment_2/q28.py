# Solving boundary value problems

import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.integrate import solve_bvp

def f1(x, y): 		#by converting the second order ode into coupled first order edes, defining their rhs
	return np.vstack((y[1], -np.exp(-2*y[0])))

def f2(x, y): 
	return np.vstack((y[1], y[1]*np.cos(x) - y[0]*np.log(y[0])))
	
def f3(x, y): 
	return np.vstack((y[1], -(2*np.power(y[1], 3) + y[0]*y[0]*y[1])/np.cos(x)))
	
def f4(x, y): 
	return np.vstack((y[1], 1/2 - (y[1]*y[1])/2 - y[0]*np.sin(x)/2))

def bc1(ya, yb):	#putting the boundary conditions
	return np.array([ya[0], yb[0] - np.log(2)])

def bc2(ya, yb):
	return np.array([ya[0] - 1, yb[0] - np.exp(1)])

def bc3(ya, yb):
	return np.array([ya[0] - np.power(2, -1/4), yb[0] - np.power(12, 1/4)/2])

def bc4(ya, yb):
	return np.array([ya[0] - 2, yb[0] - 2])
	
n = 20 #no. of points to solve	
	
x1 = np.linspace(1, 2, n)
x2 = np.linspace(0, math.pi/2, n)
x3 = np.linspace(math.pi/4, math.pi/3, n)
x4 = np.linspace(0, math.pi, n)

y_a = np.zeros((2, x1.size)) 
y_a[0] = 1

y1 = np.zeros(n)	#declaring arrays that store the analytic soln
y2 = np.zeros(n)
y3 = np.zeros(n)
y4 = np.zeros(n)

sol_1 = solve_bvp(f1, bc1, x1, y_a)	#solving using solve_bvp
sol_2 = solve_bvp(f2, bc2, x2, y_a)
sol_3 = solve_bvp(f3, bc3, x3, y_a)
sol_4 = solve_bvp(f4, bc4, x4, y_a)

y1_plot = sol_1.sol(x1)[0]	#storing the numerical solns
y2_plot = sol_2.sol(x2)[0]
y3_plot = sol_3.sol(x3)[0]
y4_plot = sol_4.sol(x4)[0]

for i in range (0, 20):		#storing the analytic solns
	y1[i] = np.log(x1[i])
	y2[i] = np.exp(np.sin(x2[i]))
	y3[i] = np.sqrt(np.sin(x3[i]))
	y4[i] = 2 + np.sin(x4[i])


figure, axes = plt.subplots(nrows = 2, ncols = 2)	#plotiing

axes[0, 0].plot(x1, y1_plot,' b')
axes[0, 0].plot(x1, y1, 'r')
axes[0, 0].set_title('1')
axes[0, 0].set_xlabel('x')
axes[0, 0].set_ylabel('y(x)')

axes[0, 1].plot(x2, y2_plot, 'b')
axes[0, 1].plot(x2, y2, 'r')
axes[0, 1].set_title('2')
axes[0, 1].set_xlabel('x')
axes[0, 1].set_ylabel('y(x)')

axes[1, 0].plot(x3, y3_plot, 'b')
axes[1, 0].plot(x3, y3, 'r')
axes[1, 0].set_title('3')
axes[1, 0].set_xlabel('x')
axes[1, 0].set_ylabel('y(x)')

axes[1, 1].plot(x4, y4_plot, 'b')
axes[1, 1].plot(x4, y4, 'r')
axes[1, 1].set_title('4')
axes[1, 1].set_xlabel('x')
axes[1, 1].set_ylabel('y(x)')

figure.tight_layout()
plt.savefig()	