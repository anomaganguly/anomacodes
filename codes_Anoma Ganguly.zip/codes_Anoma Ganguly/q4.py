# Power method to find dominant eigenvalue and eigenvector

import numpy as np

def eval(a, x):  # Defining the function to compute eigenvalue of matrix A
	ev = np.matmul(np.matmul(a,x),x)/np.matmul(x,x)
	return ev
	
a = np.array([[2.0, -1.0, 0.0], [-1.0, 2.0, -1.0], [0.0, -1.0, 2.0]]) # Initializing matrix A
x = np.array([1.0, 1.0, 1.0]) # Initial guess to the solution

ecom = 1.0;

while(ecom > 0.01): # Setting tolerance of 0.01 on accuracy of eigenvalue 
	xi = x;
	x = np.matmul(a, x)
	ecom = abs(eval(a,x) - eval(a, xi)) # Comparing the two iterative eigenvalues

print("The dominant eigenvalue is:", eval(a, x), "/nThe dominant eigenvector is: ", x)
