import numpy as np
from numpy.linalg import qr

a = np.array([[5.0, -2.0], [-2.0, 8.0]]) # Initializing matrix A
acom = abs(a - np.diag(np.diag(a)))
count = 0
while(np.any(acom > 0.001)): # Setting the accuracy on eigenvalues of A
	q, r = np.linalg.qr(a) # Doing QR Decomposition of A
	a = np.matmul(r, q) 
	acom = abs(a - np.diag(np.diag(a))) # Comparing the two iterative solutions
	count  = count + 1


print('The number of iterations are: ',count)
print('Eigenvalues usng qr decomposition are: ' ,np.diag(a))
print('Eigenvalues usng eigenvalue fn in numpy are: ' ,np.linalg.eigvalsh(a))