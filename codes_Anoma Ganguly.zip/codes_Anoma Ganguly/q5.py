# Singular Value Decomposition of a Matrix

import numpy as np
import time

np.set_printoptions(precision = 4)
np.set_printoptions(suppress = True)

a = np.array([[0.0, 1.0, 1.0], [0.0, 1.0, 0.0], [1.0, 1.0, 0], [0.0, 1.0, 0.0], [1.0, 0.0, 1.0]]) #Initialising matrix A


start_time = time.time() # Starting the clock

at = np.transpose(a)

w = np.matmul(a,at)
v1 = np.matmul(at, a)

ev1, u = np.linalg.eigh(w)
srt = ev1.argsort()[::-1]  #Sorting eigenvalues and eigenvectors in descending order
ev1 = ev1[srt]
u = u[:, srt]

ev2, v = np.linalg.eigh(v1)
srt = ev2.argsort()[::-1]  #Sorting eigenvalues and eigenvectors in descending order
ev2 = ev2[srt]
v = v[:, srt]

s = np.matmul(np.transpose(u), np.matmul(a, v))

stop_time = time.time() # Stopping the clock

print("SVD decomposition using this method is: U\n" ,u ,'\nS', s,'\nVT', np.transpose(v))
print("Time taken in my method: ", stop_time - start_time, 'seconds')


ti = time.time()

u1, s1, vf = np.linalg.svd(a) # Using the numpy built-in fn to do SVD

tf = time.time()

print("SVD decomposition using inbuilt numpy fn is:" 'u',u1, '\ns', s1, '\nv', vf)
print("Time taken: ", tf - ti, 'seconds')
