/* To do LU Decomposition of a matrix */

#include <stdio.h>
#include<math.h>
#include<stdlib.h>
#include<gsl/gsl_vector.h>
#include<gsl/gsl_matrix.h>
#include<gsl/gsl_linalg.h>
#include<gsl/gsl_math.h>

int 
main()
{
	float x;
	int s;
	gsl_matrix *A=gsl_matrix_calloc(3,3); 
	gsl_vector *v=gsl_vector_calloc(3);
	gsl_vector *w=gsl_vector_calloc(3);
	gsl_permutation *pm = gsl_permutation_alloc(3);

	printf("Enter the matrix A row-wise:\n"); /* Entering the matrix A */
	for(int i=0;i<3;i++)
	{
	   for(int j=0;j<3;j++)
	   {	
		printf("Enter the element\n");
		scanf("%f", &x);
		gsl_matrix_set(A, i, j, x);
	   }
	}
	printf("Enter the vector v:\n");  /* Entering vector B to solve AX = B */

	for(int i=0; i<3; i++)
	   {	
		printf("Enter the element\n");
		scanf("%f", &x);
		gsl_vector_set(v, i, x);
	   }
	gsl_linalg_LU_decomp(A, pm, &s); /* Performing LU Decomposition */
	gsl_linalg_LU_solve (A, pm, v, w); /* Finding the solution to AX = B using LU Decomposition */
	
	printf("The solution is:\n");

	for(int i=0; i<3; i++)
	   {	
		printf("%lf\n",gsl_vector_get (w, i));
	   }
	
printf("/n This is the same solution we got by using numpy.linalg.solve in python code, hence LU Decomposition has been done correctly.");

return(0);
}