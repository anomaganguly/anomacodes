import numpy as np
from numpy.linalg import inv

a = np.array([[0.2, 0.1, 1.0, 1.0, 0.0],[0.1, 4.0, -1.0, 1.0, -1.0],
[1.0, -1.0, 60.0, 0.0, -2.0], [1.0, 1.0, 0.0, 8.0, 4.0], [0.0, -1.0, -2.0, 4.0, 700.0]]) # Initialising matrix A

av = np.diag(a) # Gives a vector with entries which are diagonal elements of A
d = np.diag(av) # Converting vector av into a diagonal matrix 
u = np.triu(-a, 1) # Upper triangular part of matrix -A
l = np.tril(-a, -1) # Lower triangular part of matrix -A

b = np.array([1.0, 2.0, 3.0, 4.0, 5.0]) # Initialising vector B
  
xsol = np.array([[7.859713071, 0.422926408, -0.073592239, -0.5410643016, 
0.010626163]]) # True solution of linear set of equations AX=B

x1 = np.zeros(5) # Initial guess to the solution

xcom1 = abs(xsol-x1) # This compares the guess solution(taken to be 0) with the true solution

cnt1 = 0

#Jacobi Method
while(np.any(xcom1 > 0.01)):  # Setting the tolerance 0.01 on error in iterative soln
		dinv = inv(d)
		x1 = np.matmul(np.matmul(dinv,l+u),x1) + np.matmul(dinv,b)
		cnt1 = cnt1 + 1
		xcom1 = abs(xsol - x1)
	

print('The solution from Jacobi Method: ', x1)
print('The number of iterations required: ', cnt1)

#Gauss Seidel
cnt2 = 0
x2 = np.zeros(5)
xcom2 = abs(xsol)

while(np.any(xcom2 > 0.01)): # Setting the tolerance 0.01 on error in iterative soln
		t = np.matmul(inv(d-l),u)
		c = np.matmul(inv(d-l),b)
		x2 = np.matmul(t,x2) + c
		cnt2 = cnt2 + 1
		xcom2 = abs(xsol - x2)

print('The solution from Gauss Seidel Method: ', x2)
print('The number of iterations required: ', cnt2)

#Relaxation method
w = 1.25
cnt3 = 0
x3 = np.zeros(5)
xcom3 = abs(xsol)

while(np.any(xcom3 > 0.01)): # Setting the tolerance 0.01 on error in iterative soln
		t = np.matmul(inv(d-w*l),(1-w)*d + w*u)
		cwb = np.matmul(w*inv(d-w*l),b)
		x3 = np.matmul(t,x3) + cwb
		cnt3 = cnt3 + 1
		xcom3 = abs(xsol - x3)

print('The solution from Relaxation Method: ', x3)
print('The number of iterations required: ', cnt3)

#Conjugate gradient method
x4 = np.zeros(5)
g = b - np.dot(a,x4)
p = g
xcom4 = abs(xsol)
cnt4 = 0

	
while(np.any(xcom4 > 0.01)): # Setting the tolerance 0.01 on error in iterative soln
	be =  (np.matmul(np.transpose(g), g))/(np.matmul(np.transpose(p), np.matmul(a,p)))
	x4 = x4 + be*p
	gi = g
	g = g - be*(np.matmul(a,p))
	l =  ((np.matmul(np.transpose(g),g)))/(np.matmul(np.transpose(gi),gi))
	p = g + l*p
	cnt4 = cnt4 + 1
	xcom4 = abs(xsol - x4) 
print('The solution from Conjugate gradient Method: ', x4)
print('The number of iterations required: ', cnt4)