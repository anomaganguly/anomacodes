# Solving linear system of equations using numpy fn

import numpy as np

a = np.array([[1.0, 0.67, 0.33], [0.45, 1.0, 0.55], [0.67, 0.33, 1.0]])  # Initialising matrix A

b = np.array([2.0, 2.0, 2.0]) #Initialising vector B

x = np.linalg.solve(a, b) # Solving the linear system of equation AX = B

print(x) # Printing solution X